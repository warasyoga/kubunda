<?php

return [
    'name'          =>  'Kepegawaian',
    'description'   =>  'Pengelolaan data kepegawaian mLITE.',
    'author'        =>  'Basoro',
    'category'      =>  'manajemen', 
    'version'       =>  '1.1',
    'compatibility' =>  '5.*.*',
    'icon'          =>  'group',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
