<?php

return [
    'name'          =>  'Apotek Ralan',
    'description'   =>  'Modul apotek rawat jalan untuk mLITE',
    'author'        =>  'Basoro',
    'category'      =>  'farmasi', 
    'version'       =>  '1.0',
    'compatibility' =>  '5.*.*',
    'icon'          =>  'shopping-cart',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
