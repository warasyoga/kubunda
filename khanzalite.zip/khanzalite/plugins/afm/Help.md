Untuk menggunakan fitur ini, silahkan ikuti langkah-langkah berikut!
1. Aktifkan modul AFM (Anjungan finger mandiri). Jika anda bisa membaca tutorial ini berarti anda sudah mengaktifkan modulnya (LOL) ...!!
2. Isikan kredensial di pengaturan AFM, yag terdiri dari token AFM, username finger dan password finger BPJS.
3. Download file AFM di mLITE.id dengan klik <a href="https://mlite.id/page/afm" target="_blank">mlite.id/page/afm</a>
4. Extract dan jalankan file hasil download point 3 di Anjungan Finger mandiri
5. Silahkan ujicoba

Jika ada kesulitan silahkan tanyakan di grup
