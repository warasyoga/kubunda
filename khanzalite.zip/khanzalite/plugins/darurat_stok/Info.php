<?php

    return [
        'name'          =>  'Darurat Stok',
        'description'   =>  'Modul databarang untuk mLITE',
        'author'        =>  'Basoro',
        'category'      =>  'farmasi', 
        'version'       =>  '1.0',
        'compatibility' =>  '5.*.*',
        'icon'          =>  'code',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
