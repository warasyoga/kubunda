<?php

    return [
        'name'          =>  'Jam Masuk',
        'description'   =>  'Modul jam masuk untuk mLITE',
        'author'        =>  'Basoro',
        'category'      =>  'manajemen', 
        'version'       =>  '1.0',
        'compatibility' =>  '5.*.*',
        'icon'          =>  'code',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
