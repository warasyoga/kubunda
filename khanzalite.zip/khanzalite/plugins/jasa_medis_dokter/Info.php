<?php

    return [
        'name'          =>  'Jasa Medis Dokter',
        'description'   =>  'Modul jasa medis dokter untuk mLITE',
        'author'        =>  'Basoro',
        'category'      =>  'keuangan', 
        'version'       =>  '1.0',
        'compatibility' =>  '5.*.*',
        'icon'          =>  'code',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
