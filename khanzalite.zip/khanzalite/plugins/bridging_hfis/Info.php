<?php

    return [
        'name'          =>  'Bridging HFIS',
        'description'   =>  'Modul Bridging HFIS di mLITE',
        'author'        =>  'Adly',
        'category'      =>  'bridging', 
        'version'       =>  '1.0',
        'compatibility' =>  '5.*.*',
        'icon'          =>  'shield',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
