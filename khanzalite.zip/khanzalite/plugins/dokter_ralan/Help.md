<div class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src="//www.youtube.com/embed/QUQcYPunyyc" allowfullscreen></iframe>
</div>
