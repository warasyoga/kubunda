<?php

    return [
        'name'          =>  'Jasa Medis Perawat',
        'description'   =>  'Modul jasa medis perawat untuk mLITE',
        'author'        =>  'Basoro',
        'category'      =>  'keuangan', 
        'version'       =>  '1.0',
        'compatibility' =>  '5.*.*',
        'icon'          =>  'code',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
