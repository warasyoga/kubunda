<?php

return [
    'name'          =>  'Apotek Ranap',
    'description'   =>  'Modul apotek rawat inap untuk mLITE',
    'author'        =>  'Basoro',
    'category'      =>  'farmasi', 
    'version'       =>  '1.0',
    'compatibility' =>  '5.*.*',
    'icon'          =>  'shopping-cart',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
