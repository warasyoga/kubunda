<?php

return [
    'name'          =>  'Kasir Rawat Inap',
    'description'   =>  'Modul kasir rawat inap untuk mLITE',
    'author'        =>  'Basoro',
    'category'      =>  'keuangan', 
    'version'       =>  '1.0',
    'compatibility' =>  '5.*.*',
    'icon'          =>  'money',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
