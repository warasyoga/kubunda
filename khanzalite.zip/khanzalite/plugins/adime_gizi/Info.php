<?php

    return [
        'name'          =>  'Adime Gizi',
        'description'   =>  'Modul catatan adime gizi untuk mLITE',
        'author'        =>  'Basoro',
        'category'      =>  'rekammedik', 
        'version'       =>  '1.0',
        'compatibility' =>  '5.*.*',
        'icon'          =>  'code',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
