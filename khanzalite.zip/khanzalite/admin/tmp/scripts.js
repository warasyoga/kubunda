jQuery().ready(function () {
    var var_tbl_penyakit = $('#tbl_penyakit').DataTable({
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        'dom': 'Bfrtip',
        'searching': false,
        'select': true,
        'colReorder': true,
        "bInfo" : false,
        "ajax": {
            "url": "http://localhost/khanzalite/admin/icd_10/data?t=ca2147185eb6",
            "dataType": "json",
            "type": "POST",
            "data": function (data) {

                // Read values
                var search_field_penyakit = $('#search_field_penyakit').val();
                var search_text_penyakit = $('#search_text_penyakit').val();
                
                data.search_field_penyakit = search_field_penyakit;
                data.search_text_penyakit = search_text_penyakit;
                
            }
        },
        "columns": [
{ 'data': 'kd_penyakit' },
{ 'data': 'nm_penyakit' },
{ 'data': 'ciri_ciri' },
{ 'data': 'keterangan' },
{ 'data': 'kd_ktg' },
{ 'data': 'status' }

        ],
        "columnDefs": [
{ 'targets': 0},
{ 'targets': 1},
{ 'targets': 2},
{ 'targets': 3},
{ 'targets': 4},
{ 'targets': 5}

        ],
        buttons: [],
        "scrollCollapse": true,
        // "scrollY": '48vh', 
        "pageLength":'25', 
        "lengthChange": true,
        "scrollX": true,
        dom: "<'row'<'col-sm-12'tr>><<'pmd-datatable-pagination' l i p>>"
    });

    // ==============================================================
    // FORM VALIDASI
    // ==============================================================

    $("form[name='form_penyakit']").validate({
        rules: {
kd_penyakit: 'required',
nm_penyakit: 'required',
ciri_ciri: 'required',
keterangan: 'required',
kd_ktg: 'required',
status: 'required'

        },
        messages: {
kd_penyakit:'kd_penyakit tidak boleh kosong!',
nm_penyakit:'nm_penyakit tidak boleh kosong!',
ciri_ciri:'ciri_ciri tidak boleh kosong!',
keterangan:'keterangan tidak boleh kosong!',
kd_ktg:'kd_ktg tidak boleh kosong!',
status:'status tidak boleh kosong!'

        },
        submitHandler: function (form) {
 var kd_penyakit= $('#kd_penyakit').val();
var nm_penyakit= $('#nm_penyakit').val();
var ciri_ciri= $('#ciri_ciri').val();
var keterangan= $('#keterangan').val();
var kd_ktg= $('#kd_ktg').val();
var status= $('#status').val();

 var typeact = $('#typeact').val();

 var formData = new FormData(form); // tambahan
 formData.append('typeact', typeact); // tambahan

            $.ajax({
                url: "http://localhost/khanzalite/admin/icd_10/aksi?t=ca2147185eb6",
                method: "POST",
                contentType: false, // tambahan
                processData: false, // tambahan
                data: formData,
                success: function (data) {
                    if (typeact == "add") {
                        alert("Data Berhasil Ditambah");
                    }
                    else if (typeact == "edit") {
                        alert("Data Berhasil Diubah");
                    }
                    $("#modal_cs").hide();
                    location.reload(true);
                }
            })
        }
    });

    // ==============================================================
    // KETIKA MENGETIK DI INPUT SEARCH
    // ==============================================================
    $('#search_text_penyakit').keyup(function () {
        var_tbl_penyakit.draw();
    });
    // ==============================================================
    // CLICK TANDA X DI INPUT SEARCH
    // ==============================================================
    $("#searchclear_penyakit").click(function () {
        $("#search_text_penyakit").val("");
        var_tbl_penyakit.draw();
    });

    // ===========================================
    // Ketika tombol Edit di tekan
    // ===========================================

    $("#edit_data_penyakit").click(function () {
        var rowData = var_tbl_penyakit.rows({ selected: true }).data()[0];
        if (rowData != null) {

            var kd_penyakit = rowData['kd_penyakit'];
var nm_penyakit = rowData['nm_penyakit'];
var ciri_ciri = rowData['ciri_ciri'];
var keterangan = rowData['keterangan'];
var kd_ktg = rowData['kd_ktg'];
var status = rowData['status'];



            $("#typeact").val("edit");
  
            $('#kd_penyakit').val(kd_penyakit);
$('#nm_penyakit').val(nm_penyakit);
$('#ciri_ciri').val(ciri_ciri);
$('#keterangan').val(keterangan);
$('#kd_ktg').val(kd_ktg);
$('#status').val(status);

            //$("#kd_penyakit").prop('disabled', true); // GA BISA DIEDIT KALI DISABLE
            $('#modal-title').text("Edit Data ICD 10");
            $("#modal_penyakit").modal();
        }
        else {
            alert("Silakan pilih data yang akan di edit.");
        }

    });

    // ==============================================================
    // TOMBOL  DELETE DI CLICK
    // ==============================================================
    jQuery("#hapus_data_penyakit").click(function () {
        var rowData = var_tbl_penyakit.rows({ selected: true }).data()[0];


        if (rowData) {
var kd_penyakit = rowData['kd_penyakit'];
            var a = confirm("Anda yakin akan menghapus data dengan kd_penyakit=" + kd_penyakit);
            if (a) {

                $.ajax({
                    url: "http://localhost/khanzalite/admin/icd_10/aksi?t=ca2147185eb6",
                    method: "POST",
                    data: {
                        kd_penyakit: kd_penyakit,
                        typeact: 'del'
                    },
                    success: function (data) {
                        data = JSON.parse(data);
                        if(data.status === 'success') {
                            alert(data.msg);
                        } else {
                            alert(data.msg);
                        }
                        location.reload(true);
                    }
                })
            }
        }
        else {
            alert("Pilih satu baris untuk dihapus");
        }
    });

    // ==============================================================
    // TOMBOL TAMBAH DATA DI CLICK
    // ==============================================================
    jQuery("#tambah_data_penyakit").click(function () {

        $('#kd_penyakit').val('');
$('#nm_penyakit').val('');
$('#ciri_ciri').val('');
$('#keterangan').val('');
$('#kd_ktg').val('');
$('#status').val('');


        $("#typeact").val("add");
        $("#kd_penyakit").prop('disabled', false);
        
        $('#modal-title').text("Tambah Data ICD 10");
        $("#modal_penyakit").modal();
    });

    // ===========================================
    // Ketika tombol lihat data di tekan
    // ===========================================
    $("#lihat_data_penyakit").click(function () {

        var search_field_penyakit = $('#search_field_penyakit').val();
        var search_text_penyakit = $('#search_text_penyakit').val();

        $.ajax({
            url: "http://localhost/khanzalite/admin/icd_10/aksi?t=ca2147185eb6",
            method: "POST",
            data: {
                typeact: 'lihat', 
                search_field_penyakit: search_field_penyakit, 
                search_text_penyakit: search_text_penyakit
            },
            dataType: 'json',
            success: function (res) {
                var eTable = "<div class='table-responsive'><table id='tbl_lihat_penyakit' class='table display dataTable' style='width:100%'><thead><th>Kd Penyakit</th><th>Nm Penyakit</th><th>Ciri Ciri</th><th>Keterangan</th><th>Kd Ktg</th><th>Status</th></thead>";
                for (var i = 0; i < res.length; i++) {
                    eTable += "<tr>";
                    eTable += '<td>' + res[i]['kd_penyakit'] + '</td>';
eTable += '<td>' + res[i]['nm_penyakit'] + '</td>';
eTable += '<td>' + res[i]['ciri_ciri'] + '</td>';
eTable += '<td>' + res[i]['keterangan'] + '</td>';
eTable += '<td>' + res[i]['kd_ktg'] + '</td>';
eTable += '<td>' + res[i]['status'] + '</td>';
                    eTable += "</tr>";
                }
                eTable += "</tbody></table></div>";
                $('#forTable_penyakit').html(eTable);
            }
        });

        $('#modal-title').text("Lihat Data");
        $("#modal_lihat_penyakit").modal();
    });

    // ==============================================================
    // TOMBOL DETAIL penyakit DI CLICK
    // ==============================================================
    jQuery("#lihat_detail_penyakit").click(function (event) {

        var rowData = var_tbl_penyakit.rows({ selected: true }).data()[0];

        if (rowData) {
            var kd_penyakit = rowData['kd_penyakit'];
            var baseURL = mlite.url + '/' + mlite.admin;
            event.preventDefault();
            var loadURL =  baseURL + '/icd_10/detail/' + kd_penyakit + '?t=' + mlite.token;
        
            var modal = $('#modal_detail_penyakit');
            var modalContent = $('#modal_detail_penyakit .modal-content');
        
            modal.off('show.bs.modal');
            modal.on('show.bs.modal', function () {
                modalContent.load(loadURL);
            }).modal();
            return false;
        
        }
        else {
            alert("Pilih satu baris untuk detail");
        }
    });
        
    // ===========================================
    // Ketika tombol export pdf di tekan
    // ===========================================
    $("#export_pdf").click(function () {

        var doc = new jsPDF('p', 'pt', 'A4'); /* pilih 'l' atau 'p' */
        var img = "iVBORw0KGgoAAAANSUhEUgAAAT0AAAE9CAYAAAB5m7WdAAAAAXNSR0IArs4c6QAAIABJREFUeF7tfVtvW1eW5tqHVC7TU102MJPq6luUnhqkuzDVURqYBiaWHBr1HIVBFKDeinlkLKPkXxDlF0SB7fCx6LcAVlCU/ANMWUq9lgz0e1lo9EMDjSqxM9WtFMmzZzZ5KFMSL+e61jo8HwFDgLnPXmt/394f92XtdQzhAwRSROCjB9UV69M1Ir9iPbpmfFoZVG8Gf78/x1SHLB27MtajY+PTKZHXNh6dPrrdGvw/PkAgKQImaQV4vrgIVD+vXiuV+xXyTGUgbobezRQNSwdODMm37X6v1G7dbZ1mag+VLyQCEL2FpDW7Rg1mcrZfMWRqluit7CzNr9kQPbNkm8aU2pgJzscLJYYIQPTQE+Yi8LNGdbnX71eJvC0i+/rcB0QKmBMif6dcKrW+qreei7gAo7lAAKKXC5pknPzw3ntVY0yNiN6X8SC21T1rbfPrO49bsWvAgwuLAERvYamN37CPHrxXs9bb1jurC9s2c2KMv/3o9uNm2CdQbvERgOgtPsehW7g4Yne5yRC/0J2gAAUhegUgeV4TF1fsIH7zuC/i9xC9IrIetHkYU+fvZB5qog1jSwfG87Zw4quNGB5/IHo8OKuzsnFvfZsMfarOMU6HLH22e2d/m9MkbMkjANGT54DVAze7I+s3pWPsWBs9w5iL9SPj1TDr08JI9n5A9LLHWI2FjfvvbRGZz9U4pMoRe3d38/GOKpfgTCYIQPQygVVXpe66WHnJd2EbeYu34wZyr9f1arjexg07rz2IHi/e7NaG18ZsK/8xd1zQufAWU8VylwtvfjsQPX7M2Sxu3KtWyPjuVsK87CZsPuXEUIesV92902rnxF+4GQEBiF4EsPJUdBh7Z36ZJ5+1+WqM/Ri3ObSxktwfiF5yDNXVAMFLjxIIX3pYaqkJoqeFiZT8gOClBORYNRC+9DGVrBGiJ4l+yrYheCkDCuHLDlDBmiF6guCnaRqClyaak+vCjC97jDksQPQ4UM7YRnBK+yRjM6jeIWC9WzjVzXdXgOjlmz8axuH5LrQCYSk8XHaM8SqI4+MBOwsrEL0sUGWqc3jTwh4j8JgJ8HMz5qTXNSu4ucGNezr2IHrp4ChSy8b9dRd4jKtlIujT3u7mflXGNKwmQQCilwQ9wWeRPEAQ/HPTSFKggYWoPkD0oiKmoHywj/cbBa4U3gVjvLexv5evbgDRyxdfA28/ur9+jHx4Oohz+fgebe6v6PAGXoRBAKIXBiVFZZDxWBEZI1eQgVkhKdNdgujliK78LWvdC7htm8geky0dG49Opy0Fh+/roGtk+itExv2r5OlUGsvc/AwkiF5+uKKNe+tt9S/xGbx0xzZLXqn9Vb31PAm8P2tUl/t+v2J9U8tDu3fv7FeStBfP8iAA0ePBObEV5dfMOmRpp1z2mkmFbhpQTgB7Pd+J35bWQGxr7Qdf33nswojwUYwARE8xOeOubdx//7nC5d5A7Ho9b4crUHcQkF32t3SKnznZ3dxbzkmXKqybEL0cUK9xlmcNfdH/o7fNJXaXaXLiV3rJ3zaWfqGJQiQl0MTGZF8gevo5Il2zPF3vkND3DhDM9rQPKYiecoaUzfIe9rreltTsbhpVwdve3Osbf66BTsz2NLCAkBXdLMzwTs8sT/+VKz1X8zDb0zzgMNNTzM6H996rGmN+Je1inmYuWmbGOMmV7rWY6ellYOYsTz6LSp4EbwSlEuFDFhalow4zPaXEDOLS+v5vJd3Lo+BpEr5yyXsjq7hFyX6Rd9sQPaUMyu9P6d/Dm0cdMJyHUDG/h+gp5V34AOPh7uZ+TSk0kdzauL/elDrVRQaWSFSxFYbosUEd3pDs0naxUqFLp9THEjd8v+cqCdHjQjqCHcll2SJmC5F9W1z+twkidN1cFIXoKaRJKkmou1r29e19d6F/4T4fPljfEbmyZukA2Vd0dSeIni4+KLhd8HsBtzq9rres7bZFWjgEuLpUV+yvyux1veuLimta/HDWA9HjRDuELbGA5AJk/5XKOo1A5RAdn7EIRI8R7DCmhJZhCz3LG+EuNtsrwA9KmL6tpQxETwsTgR8i2ZELNChFZnvY11M1yiB6qugg2ri/brldKlJYhVQ40O7mPsYad8eeYg9EKCHCuSHy4p8CzkIkZtNF+mFRNKQmugLRU8SQRDxZnu/XxqVOJA7Serd277TacX3Gc+khANFLD8vENUnsNxVxBiKyxC3QvmnigZBxBRC9jAGOUj3/yW1xk11y321e5MDvKH1cQ1mIngYW5E5uFyaxQFQa2RMRFHDvNConXOUhelxIh7DDv8Fe3Huh7Pt6EL0QI4CnCESPB+dQVjbur5+yXpMq8OY6/6FRcbcSQnV+xkIQPUaw55nijtFbxIwq8zAefS8RHoRYvbDsZFsOopctvpFq5xa9og9C4B2pey5MYYieIioxCHnJAN68eGuxBtHTwgTxX0HDTI/3yl/R8dYy1CB6WpiA6LEzgZkeO+QqDEL0VNAwdAKDkJcM4M2LtxZrED0tTED02JmA6LFDrsIgRE8FDZjpSdAA0ZNAXd4mRE+eg3MPMAh5yQDevHhrsQbR08IElrfsTED02CFXYRCip4IGLG8laIDoSaAubxOiJ88BlrdCHED0hIAXNgvREyZg3DwGIS8ZwJsXby3WIHpamMCeHjsTED12yFUYhOipoAF7ehI0QPQkUJe3CdGT5wB7ekIcQPSEgBc2C9ETJgB7enIEQPTksJe0DNGTRP+SbQxCXjKANy/eWqxB9LQwgYMMdiYgeuyQqzAI0VNBAw4yJGiA6EmgLm8ToifPAQ4yhDiA6AkBL2wWoidMAA4y5AiA6MlhL2kZoieJPg4yRNGH6InCL2YcoicG/VXDGIS8ZABvXry1WIPoaWECp7fsTED02CFXYRCip4IGnN5K0ADRk0Bd3iZET54DnN4KcQDREwJe2CxET5gAnN7KEQDRk8Ne0jJETxJ9nN6Kog/RE4VfzDhETwx6nN5KQw/Rk2ZAxj5ETwb3iVYxCHnJAN68eGuxBtHTwgRCVtiZgOixQ67CIERPBQ1DJzAIeckA3rx4a7EG0dPCBESPnQmIHjvkKgxC9FTQgJmeBA0QPQnU5W1C9OQ5OPcAg5CXDODNi7cWaxA9LUxgecvOBESPHXIVBiF6KmjA8laCBoieBOryNiF68hxgeSvEAURPCHhhsxA9YQLGzWMQ8pIBvHnx1mINoqeFCezpsTMB0WOHXIVBiJ4KGrCnJ0EDRE8CdXmbCyN6D755Z8XzvWtEVCEi93dlCK9dITLf54C6vnaUCE8MQg6WXtjgxpu3dUmsmROy9vlg9Hh0bHw6JfLa5TI9/6reGvx/nj+JBqlUwz9/Urn2cqlfMcY6gXPi9q6UL+N28yR6Sx7RzZ/87tZZr3x891b7VAN+3D5A9GIibumAiNqW7HG/V2q37rZy1X9yI3puJmesqRhrakT0Vky6Mn0sT6J3/U98+ocfjfqq7RCZ40FHtubY9EvH9Vvt3P+izyMbojcPoZDfOxE0tlUulVp5mAmqFr3Gk8qyXepWjTVbRPR6SArEiuVX9CZBZjtk3K85ta2x7ds3fu1EcaE+EL306TREzyzZpmYBVCl6Xz5dqxrPr5E176dPS3Y1LpboXcbJdsh6LTcbPOuXWouwJIboZTcWgpr3rLXNr+88dv1GzUeV6DWertXI2O08zOomMbjYonelxQfW2JbpLrXyuhSG6HHpkDkxxt9+dPtxk8viLDsqRC/vYjcCuGCiN96vnlljm991l5p5mgFC9LglSIf4iYreoogdRG9s8Bi7Z32v+cnNQ1VLmknDG6LHLXoje+bEWn9LatkrInpBTN2OllCTtKgv8ExvEoQnRNSkXrmpdfkL0Uur58esx9KB8bytR7dbrIdk7KLXOFx1e3afxoRJ9WMQvSn0WPOQjG3W147amgiE6Clhw9Jnu3f2nS6wfNhEL5jduY1MlTF2aaAN0ZuL4oG1ZkfL0heiN5cvtgIu1IWMV+OY9bGI3pdHN7aMNZ+zIShkCKIXGvgTsma7fvNQ9DQPoheaL8aC9u7u5mO39ZXZJ1PRc9fFXlnqNvMWbxcXbYheZOROrDVbUjM/iF5kvrge2Ot1vVpW19syE71gOetO8NTfpEiLSYhebCTdXc5t7j0/iF5svjJ/MMvlbiai1zhcrRDZFld2k8wZCGkAohcSqGnFjN2j7tIW12kvRC8hX9k/7m4BVXfvtFI9AEtd9ILYu19mj4c+C2e98vUkwbmcg/BiwgF1WH521ivvJMEyTIs48Q7jD8pMRsAY+3GatzlSFb0iC15A160kSzTOQfjqkqV3fvx7zeMs8/0+Trw1A50H39IUvtRED4I36DrJRO/eepsMX27An771O/39PcMlL0RPP/3jHqYlfKmIHgTvnBqIXibjyHasoe1PVr9JNZQBopcJWZlWmobwJRY9CN4FjnMleqt/9+//+vJLvR9k2kvTrfzgrFeuprXXB9FLlxyu2pIKXyLRG57S0hOuxqq3Y83HSQJuN+6vu2Ddn3O1852//fbk1Ze7OQspsh1rvVoasX0QPa6eloEd692Ke6obW/SGcXimXbSwlDn0fVZfO4p9h3Dj3vo2Gb57yW+98R///N/+9OyvMuiSHFV+UV87chm1Y38gerGh0/BgxxivEufaWizRG9y0KPdcZoSczRIy5ypXovfmD787+cvX/pBnDp9Rr1yNG9cH0ct8PGRqwAUwd7teJerNjVii1zi60SrK1bJIrBm7V1/9phrpmbHCG/eqFTI+23bBa9/r00/+phPXXSXPxV/uQvSUUJjMjb3dzf1IYy6y6BUleUBMHg7qa0dunzPWh1v0vveKpX98U3WsXhQcI8+yIXpR4NVcNlqSgkiiF9yn/Y3m5gv7dlJfO1pO4gP3QMxFrF5YQI3dO+su1cKe7nJjHbYZKBcdAWO8t8Pu70USvcbhqtvHW9h8eNGhvvpECvdv3ctov5+GL2HqyOcJ7syWPTvrlSthhA+iF6aH5KOM2997tLm/Esbb0KK3yBmPwwAVukyv/EbcjXVnY4P5VsaP//zsX3743//jL0K3LxcFbcf3bGXeu3oherkgM7yTITMwhxK9HC5rXZLKtvX8Y2PNse/5p/MGQHhksy3JHav359d7//l3f/3vr2bbKonawwmfhGeabX70oLpifbpG5FfI0DKRcRmTcnPCH2aZG0r0GoerLrXLu5rJIqIDsqZJ/VI7yUxLuo3csXo5SDyQgJLBC8q3kgSMJzC+MI/+rFFd7vX7VbKmynk3PBaAlg527+zPPEycK3q6r5nZDpHZ0fzGrajEcZ/gOv/eefP//ubVV/74dlRfc1M+4U2Z3LSTwdGBAPb8GhlygeFse89Rmjbvmtp80Ttcfa4vCHkodhw516KAnUbZ6ufVa+UlnzuOZBDrFFwrdDFP7l9uljShcIfwhYIpbKFBPy37WzrFz5zsbu5NjaKYKXpKZ3lfnPXK22FO58ISqK3cxv33nzPvo3R2N/evjePQeFJZtkvdqrGmtjAn9hC+1Lu6E7/SS/62sfSL1CtPUOGs2d5s0dM1y3Mvj64lSdKZAEPWRzfur7t3i7zPaXTWBrATQCr33HIm/zNACF8m3Wq4LWObzD/WM9oyfbY3VfRUzfKseXjWL20t8uxunL2N++9tEfG+MtMa+uLr2/tzL/B/+XStaox15bQfbE0fEBC+TIQv2JpxOQ/ZMgXNasi02d500VMyy7PG3k07eWQmjKdYqcRhBtHsfZDLzRvM/kr9bTJWRQePAX+i3Icx7BXmEYkf7cngTu7TE0Uv+DX/lThLBf5FlgicDRPjNFH8yr0akZv9GZWneZP7MeL4shzfHz14r2atEX9BmLX2g6/vPHbbReefiaKnIotKgQXPscN9M8PZDLvEnTRYgnRjLpegqg3t2QPbdqi3tJLnuM4shStp3UqE70oWliuiF2xa/zZpgxM9X3DBC0SPNaHokK9oS9xJHOdw2Rv6rm6iPl3QhzUIX7nkvfFVveVC74a9/DIX0qmjiriHN2k8DK4DWZ8/o02CNNzj7Qhi/tymdh4SVCRKCVZQPQvdbPk9voupp67O9CQPMKx5WL956OLC8HFL3PvrrBlXAtAf7m7up8bB8EeUttXv96HvZTrmuO+UX2zMxRXMBdETTixwctYrrxQlLCVMD5PqKL2udz1qCu5Z7Rns9y11m+qzbWNbJUy3jFVmGM5ij6Xi+MaXuBdET3Jp63v+23nJhBKL9RgPie2HhEzRE7VJw6gAv6l51od+GJXV8OVlQrFG/r1Y4l4QPcEkoYnfbBUe+vyUFLqHm8qBxjSUg4My96pLrcHNWHFkOEQ+fLC+I3FlbTzJ6LnoBSEH3BfdXaBE56y3tIxl7eSeJnElbXDCZezHj24/duKUyUd1UtqEL3jKBLAFqTT4IXcnqewxnaNtm3PREwxIjvxClwXhP1QzxJa4KYSvzGvg8ITXtjQudxFFMI+9+N9z54w8X+AGgcrnotc4XHXhBcyBpZjlzes6ckvc7Gd7ru3BctdFzKsLbcH+3rzeGe97qdneKPh+XPQksiNjlhei30gtcdMIVg7RPFJ8uvusvnYU6mUzYdqJMi8QEJntBVmVx0XPspOS8CU67P4KGZRb4vLM9kawNp6uNRUmMMAPcwb9fpiC3me/+bW7uW8GoicSn4fN4khdSShQOdOT3EkAqEppFjiIZW6krhq6sMT9cpdUYyB6wZWhJ6G9TaMgAkEjoSh11D9wMqO4vWkAKBQ+LHMj9dZwhUVWMNa7NRI9lx3j03CuplQKS9tIQEotBwInO72ut5zmLY15jVcofFjmziMt4vcifdrSZyPR4z65PamvHU19cUdE7ApTXGI5MAZuqndyw5CmS/iQhioMZ1HLcL8Pxp3gjkSP9+QWl7uj9o1BeZHlwLinKWVgidJ4XcJHyMYShbwQZdnvl1s6EBE9BH6G6A1TinD/Ml50w5z0umaFc5k72HN+ulYjY8Wz8AZYIM18/O575Un2tFMvRO/GKXNUPDpOzI4jEt90YbZHn+3e2Xd7wKwfmeD5iU3E1kyKzAskIeiMZnqsMXoIAYjfa6Si2S94LLDMDWZ8KuL4sFKJ338vPymRLFdE9OprRzPft5sepItZk/hsj2SWuQPhO1w9lr+yhuuTaY4s7pdgQfTSZI+pLhWzPSL201wHb5ANyAnf60xwTzODEJaUCIDopQTkolcjP9vjvaI2zufwBpFpM+9DX+pSmO2lNcYgemkhueD1KJntdYzxKo9ut9zMi/Wj5EQXs70UWIfopQBiUarQMNtzmVgkwlh0HGxgtpfGWIPopYFiQepQMttz7xF99mhznz0Fk5L9Pcz2Eo63QogeQlYS9pKxx9mDO6e7LnKwIZIs4wIGmO0l6c2CISsITk5CnPSzsrc0XrR+lJmWGw/pwGXE7cVnXDI4mfXuLTpJ/E4y6UmBjjO1AVm/UGiSYQXLXNzSiNml2VcqUndvCQkHYnaR6Y8JZ2C54JiE8Ikvc5EfMlaflkw4gNRSsSjT81CQm8yFjrC/Wm8SCiLCJ5tuHhlYYgwH7q2Z8dRSSCIagzBtj+gIYXmBCrfwDZe53ediQctIjBtpSEgnEa0QEdLFR6JMZ+GP7q8fW0WvU+QWPuGXiH9RXzva0tkz9Hklkh9ylC5e5MVAhISMWXRDiRCAee0QEL7nMndzbae+9s21eXjg+yECEvvQ5y8Gcg40DldZ00sNWo3lQCb9X9syN2gkWxyf5BU1a80Hn9w8dC8vx2cGAiJLWyI6fwVkIHqsYSsBHohmz2hoaFvmBs3c63W9Gkfm5cbhqsxsD682DdWjRX6YJ7zsm/sE171bsHPWW1q+e6t9GgopFAqNgMZlrnPeXVkrlbzqV/WWE6XMPpKzvbNe+Tr69HRqpa5PjoLnz5N5fvl0rWqM/VVmvXB6xZjtZQQ6e+Bn+HZ0yHrV3Tstt7rI7CM220PM3kxORWZ5bopl7Qdf33ncOhe9IKr995n1wKkVY7aXJeYb99fd/tL7WdqIXXfGLxEXm+1hiTu1S0jN8pxDva533W2tXEjbLpiKG0f9sZVj9oPDTmaPiax0puHJjlo6KJe9WlbLXanZHpa4k+n+8MH6jrH0i4y6+9RqxzMBXRC9L49ubBlrPud2KLCHN6RlBLzW/b2x5nastTW39EgbArG4PSxxr1Ap2w/t3d3Nx+7cwu0rv/gIxeuNHDg565VXsAGc9rAf1icSCBq9Kamf7opt2+B++QX2pVccLj5vlOH7ylvJpJYDA4TQUaLLRIQn2C93R/BtfNZHZLdHv8rxqrj4VEPkTi4ClcdZkO175mR3c2955M8V0RNe4hLSTqUxzKfXIREFH6dFbg/GWm8rjRNeqQwsSJY7ZF4+iuDF0vbK8tb9R+NJZZnKvd/G6aipPYP9kNSgvFyRW2YsLfltTfdz5zT2YbnkbSc96BBawRQ+HEvDtkq55L0x3n8mvnS7cXSjRdbIhjlA+DITvmBD2cXIqUhDFaahLrC0/0dvO+5tDqHsyoVON6VB8Ihob3dzvzrexyaKnmCg8sX+D+ELowexyuRR+IioQ5Z2ymWvGXXmJ3VIV187mjjGYpGWo4eUCN55QPJc0Rssc6XuLl4iFnt82fV0TWnmY7Qy8rJXqE8XLhRLfg/v/MjiwgHG1IOM0Rdi0eyTer81D8/6pS2Es8SQhjmPaPlFjt0ySweW7E6YGD+JJW6RfrSD2xYuFu7nsflM8cFpKc1mTr2FfhmnNfuEiGr1taNM72umiHluqsq98A2QNifW2NaS5+1MW/qKLHELciVtuGqwTT03fy6GqYRa3g6WuE/XamTsL5WN3i/OeuVtzPrSZWUxhG+IySDchWyzXCq1Lgtg45D9dacL/aY0N7srveRvS1wtmzUCZiWunbvJqmy2F7TTdojMzlmvvAPxS0/8Fkn4XqAynAEa32u5mD+JyIRFvIc7WMqW/S0y5NLjK4sCmD7LC34UZw8apbO9C+JHvXKzfqudaX629KRFd02LKXwvMP/Ra91/ev2H3/4vZhYW5jBjkPG459d0il0w0zf240e3HzencTx3pjdY5h6uSmRVjtovDwa/6N2lFgQwKnQXywfC5zaklf2CJ2uXe/p7r1j6xzd5M6jl/TDDCV3f71esb5zYvZuchQxrCLIjz1z6hjEvsgEcxrHpZU7ImjYZ62Z/bd/zT2/f+LV7Jyw+IRHIaRxfqNbd+vvT//SM/2qowmkUytGd8gHvPl0j018hMu5fRc/hxHwyxhMLJJrpBbM9/nfjzm8jSiRAYF7g7KIK3/9589t/+S+vdP8iAXRRH010M0PqJTpRGylePmRS2lDL21FjBJOMiuO5iA7MEz3X5hze1Z1L1Zs//O7kL1/7A2NS1eQZVzbur/O/rXAuknoKjCcJnedVJNHL4TJ3XvsL/X0Y0RsJX3nJdxvDsvexU2Lrte/16Sd/00mptnDVhMV6Wm0b999/nqdlZjhU0isVZlk7shZJ9NxD0qmn0oMJNUUdiFIvdEmbqVeXLL3zY97DDCJKdIKbl5RgaXMVrr6LqaPmPRNZ9FyFErFO8xqC76MjEFX0nIUP771XNca4WV+uT3Z/+tbvogOW7Ilkoqf5BU/JcEn69JUsKvMqjCV6QQpudxrKuC8yryn4PioCcUTP2RiEMPT9Vo5y8l2B5p2//fbk1Ze7nP03UW69RZllR+2js8ubk17XrERNNxZL9Jwjw/090yYyuf7FT5eEfNUWV/RcK7VePwrLwP/+H3/45z/9r9/9VdjyKZSD6KUA4lgVHWO8yui9F1Gqji16g2Xu4WqFiJ5EMYiyehBIInqjVuR1uct+gpswVm/Rb8pEHhXWuxX3VQKJRG8gfDqTEkTGsIgPpCF6o1lfuey31Efrj5H8P3/Q/de//rNvf8DIe6JYvZznPkwV5lnJBMIYSix6EL4wMOssk5bojVoXJI90Qezqtzyu/4lP//CjU05iIHopoJ1U8JwLqYgehC8FNgWqSFv0XBOC2wPu3q7qmD6InkCHS2gyDcFLVfQgfAkZFXg8C9G7uNfn7WgNqBUQPUqCd9GXt2kJXuqiB+ETUK4EJpMMwjBmx3KufRqmPHcZ7li9pHgX9SpamoKXiegNhG9wqmtbCGfhHsbR7CUdhGGtaV3yQvTCMihWrkPWq8Y9pZ3mdWp7epcNBPd0XeT+W2KQwfBMBLhEb+TEYIlG/raWU16InuYBYk6MMdU4cXjzWpWZ6DnDg5sbS92m+IvD56FQ0O+5RU/bfh9ET23H3+t1vVrUmxZhW5Op6I2cQJKCsHTwlpMSvVErhwG33rbUYQdEj7e/hbMWLXlAuDovlmIRPWcSy9049GT7jLToXZj5kXEvmWFNRQ7Ry7Z/Rand5cMj49WyWM5e9oNN9EaGG4eryMAcpTdkWFaL6F3Y8zN+jetl0RC9DDtXlKpDZjyOUuWssuyiNzbrcwGsrL/saYG2KPVoE70Rri/euGVqWS59IXrCPdnSgfG8LY7Z3XhLRUTvfK/v6VrVGOvEjzPFjzDTesxrFb1xhIKEBm72l/oND4ieVF90J7P+9qzXNGbpmajonS95h0kL3LIX4pcl25fqzoPojVweBDov9WuGTC2tPH4QPcbONjAlK3aj1qoQPYgfd+cb2suT6I0jNAx27lfJmmqSww+IHle/0yF2KkXvwrLX82uI78u2U+ZV9MZRGbyt7aV+1Vr3flaqRsnwAtHLtn8R0Z61tvn1ncetzC1FMKBqpnfZ78aTyrJd6laNdRvauNkRgddQRRdB9C43dPiu3n5l+JJqcv+mprmC6IXqJhELmRMif6dcKrW+qreeR3yYpbhq0RtHYEwA3a85Tn1T6B6LKHqXYXFL4W6vv2LIrAxE0JD7OxBCiF4KnWiYn+6ZJds0ptTmPomN04LciN5449z1tpdL/YoxdtiRIYJxuM8tPsipAAAJ50lEQVTtnl6sxo49NMz+Qis/Xfk31lcdJP2RUZNlxdKB9eiYfNvu90rtrK6LJeV52vO5FL1JjXEzQSr3lgMRvEY0+EV3H/d/OBWeAFrSQZhVp+Sqt3G4arlsOTtJ8WYUvQ5Zcm87JCduxqdTIq9tPDrNw0xuHqcLI3rzGpqH7/M2CPOA6SwfgXfeGYznP0QvHm6ZPIVBmAmsUysF3rx4a7EG0dPCxDD5aq6WW4qgi+UK8I4FW+4fgugpohCDkJcM4M2LtxZrED0tTGCmx84ERI8dchUGIXoqaBg6gUHISwbw5sVbizWInhYmIHrsTED02CFXYRCip4IGzPQkaIDoSaAubxOiJ8/BuQcYhLxkAG9evLVYg+hpYQLLW3YmIHrskKswCNFTQQOWtxI0QPQkUJe3CdGT5wDLWyEOIHpCwAubhegJEzBuHoOQlwzgzYu3FmsQPS1MYE+PnQmIHjvkKgxC9FTQgD09CRogehKoy9uE6MlzgD09IQ4gekLAC5uF6AkTgD09OQIgenLYS1qG6Emif8k2BiEvGcCbF28t1iB6WpjAQQY7ExA9dshVGIToqaABBxkSNED0JFCXtwnRk+cABxlCHED0hIAXNgvREyYABxlyBED05LCXtAzRk0QfBxmi6EP0ROEXMw7RE4P+qmEMQl4ygDcv3lqsQfS0MIHTW3YmIHrskKswCNFTQQNObyVogOhJoC5vE6InzwFOb4U4gOgJAS9sFqInTABOb+UIgOjJYS9pGaIniT5Ob0XRh+iJwi9mHKInBj1Ob6Whh+hJMyBjH6Ing/tEqxiEvGQAb168tViD6GlhAiEr7ExA9NghV2EQoqeChqETGIS8ZABvXry1WIPoaWECosfOBESPHXIVBiF6KmjATE+CBoieBOryNiF68hyce4BByEsG8ObFW4s1iJ4WJrC8ZWcCoscOuQqDED0VNGB5K0EDRE8CdXmbED15DrC8FeIAoicEvLBZiJ4wAePmMQh5yQDevHhrsQbR08IE9vTYmYDosUOuwiBETwUNMnt6vue/ffvGr48VQcDmyoNv3lnxfO83bAaJqL52hPHGCfgUWyBBAQkjFxqHq8+J6HVGl27V147ajPbUmGocrlaI6AmjQyf1taNlRnswBdHT3wcah6tOgN5l9PSz+trRNqM9Naa+PLqxZaz5nNGhg/rakRNafIQRwExPmIBx8+yiZ83D+s3DmiII2FxpPF1rkrE/ZzNIBNFjBHuWKYieEiKcG43D1R0i+gWjS4VdcglsJXxRXzvaYuQWprC81d8HGoerbqn5KaunvfIb9Vttt5dYmE/jSWWZyr3fMje4sFsJzDjPNYeZ3lyI+AoIbK6TNfbuJ6vfuBlmYT6Np2s1MvaXzA0u7KERM85zzUH05kLEV0BoBlK4vSb2vVPXhQo4o+YbOdEsQfSi4ZV5ae6A2UGDCjQghX5YEKOX+cgJbwCiFx4rlpIisxCiwuw3ieyb4uSWZeyENQLRC4sUUzmZQWk7Z72l5bu32qdMzRQx8/mTyrVXyt3nROb7zA4U5keFGddY5iB6sWDL7qEvn65VjbG/ys7C1JoXfmDK/KAQWWs++OTmYUuAU5icgABET1m3GM5Ger/nd2uxZ3uCszw665WvL/osmr+/xrcI0YuPXWZPCu3rufYsbACtQOD3qH8U7nQ8s4GRUsUQvZSATLMagXuh4+4vXDyZREaVEaBFjINMcyxkURdELwtUE9YpFVYRuH1y1iuvLMpyLNgucOmzOLPXvOgBBQoHStjt2R6H6LFBHc1Q43DVDdS3oj2VUukFSkQgkFhgnIRn9bWjlZRYQTUpIQDRSwnItKsRXuIuxPU0YJh2r1yM+iB6SnkUXuIOUbHm4/rNw6ZSiGa6JXS/9qJPWNqq7DoQPZW0DJ1qHN1okTXvi7qYQ+FTIXjG7tVXv6mKcgfjExGA6CnuGIKByhdRyZHwqRA8N0lGQLLakQXRU0tNMNvjf2/GRETyEHohvYc3Blxhk7MqH04D9yB6ylnSMnMJ9vgenvVLW9rCWQZhKaX+DnP69+k9J0czY+XdPxP3IHqZwJpupQKpzWc14MT3/KqWV0cGgcfuXqtMHN5VpDDLS7f7p14bRC91SNOvUNVs70XzvjjrlbelZn1B0LFLr8/5TpH55GKWNx8j4RIQPWECwppXNtsL3LYdIrNz1ivvcIlfIHZbRHZLIEXUPLowy5uHkILvIXoKSAjjgpqT3MnHHAPxo165mdVLhoK4xZpSsRtueeLENkxXFi8D0ROnILwDgtlXwjtJdEDWNKlfaicVwIHQlfoVMta9m5fzJehR2jsqi2wqcVATeAaiJwB6XJOS2UJi+nxC1rSt5x8ba459zz+ddgAStO2aNXbF+N4KGVtRdDgxt/m+57+t5XBnrrMFLwDRy1kHkMr+mzOYuN1d+KzT3IBmaQ+ilyW6GdUtmoElozbluFpkUskZeRC9nBHm3M3hMjeHKIdzGcvacDhpKgXR08RGBF8UXbmK4PViFc3D1bzFQjyd1kD00sFRpBYVWVhEWq7AKLKoKCAhngsQvXi4qXhKPBW6ChREnFiolPoiCAoahegJgp+G6eH+nmkrvJ2QRvMU1mE7vmcrCE9RSE1IlyB6IYHSXKxxuOpi2p5o9nGBfFu4t8UtEDehmgLRCwWT/kJKkxLoBy6Kh0gmEAUttWUhemqpie4YhC86ZqGfgOCFhkp7QYiedoYi+gfhiwhYmOIQvDAo5aYMRC83VIV3FMIXHqu5JSF4cyHKWwGIXt4YC+kvhC8kULOKQfBSAFFfFRA9fZyk5tHwVNe2EM4SFdJBctRqfe2oHfVJlNePAERPP0eJPFT4DolE7WF4WNU7QBjaWzgTEL0CUD64ubHUbYq/OFw71sbunXWXalyp77XDsaj+QfQWldkJ7UKSgulkI3lAcQYCRK84XA9aGix3m0T0VsGaPq25z3zPr+FaWXF6A0SvOFxfaCkyMA/gQMbjAvZ/iF4BSR81OZj17eTgpTtps3Tge/4WZndpw5qP+iB6+eApUy+DmD734uzXMzUkX7l7UdF2/eahW97jU1AEIHoFJX5SsxdY/CB26OfnCED00BmuILBA4gexQ/++ggBED51iKgJfPl2rGs+v5S6+z9g963vNT24etkAvELiMAEQPfWIuAo0nlWW71K0aa7YU7/udWGN3THepVb/Vfj63UShQWAQgeoWlPl7D3YmvsaZirKkpiPV7Zo1tWmPbOImNx2cRn4LoFZH1lNrsrre9XOpXjLEuXf0KQ+jLAREdW2va3/VLbVwXS4nIglUD0SsY4Vk3N4j9u0ZETgjdXyeGRGRX5md7GWQ3OQ58dH9PrTXHttR/jplc1swVp36IXnG4RkuBABD4/wj8P+fNZts5+jAmAAAAAElFTkSuQmCC";
        doc.addImage(img, 'JPEG', 20, 10, 50, 50);
        doc.setFontSize(20);
        doc.text("Klinik Ibunda", 80, 35, null, null, null);
        doc.setFontSize(10);
        doc.text("Jl. Pramuka No.392, Dusun Rw. Gembol, Purworejo, Kec. Purwareja Klampok, Kab. Banjarnegara, Jawa Tengah 53472 - Banjarnegara - Jawa Tengah", 80, 46, null, null, null);
        doc.text("Telepon: 082118310196 - Email: yogastaffitibunda@gmail.com", 80, 56, null, null, null);
        doc.line(20,70,572,70,null); /* doc.line(20,70,820,70,null); --> Jika landscape */
        doc.line(20,72,572,72,null); /* doc.line(20,72,820,72,null); --> Jika landscape */
        doc.setFontSize(14);
        doc.text("Tabel Data Penyakit", 20, 95, null, null, null);
        const totalPagesExp = "{total_pages_count_string}";        
        doc.autoTable({
            html: '#tbl_lihat_penyakit',
            startY: 105,
            margin: {
                left: 20, 
                right: 20
            }, 
            styles: {
                fontSize: 10,
                cellPadding: 5
            }, 
            didDrawPage: data => {
                let footerStr = "Page " + doc.internal.getNumberOfPages();
                if (typeof doc.putTotalPages === 'function') {
                footerStr = footerStr + " of " + totalPagesExp;
                }
                doc.setFontSize(10);
                doc.text(footerStr, data.settings.margin.left, doc.internal.pageSize.height - 10);
           }
        });
        if (typeof doc.putTotalPages === 'function') {
            doc.putTotalPages(totalPagesExp);
        }
        // doc.save('table_data_penyakit.pdf')
        window.open(doc.output('bloburl'), '_blank',"toolbar=no,status=no,menubar=no,scrollbars=no,resizable=no,modal=yes");  
              
    })

    // ===========================================
    // Ketika tombol export xlsx di tekan
    // ===========================================
    $("#export_xlsx").click(function () {
        let tbl1 = document.getElementById("tbl_lihat_penyakit");
        let worksheet_tmp1 = XLSX.utils.table_to_sheet(tbl1);
        let a = XLSX.utils.sheet_to_json(worksheet_tmp1, { header: 1 });
        let worksheet1 = XLSX.utils.json_to_sheet(a, { skipHeader: true });
        const new_workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(new_workbook, worksheet1, "Data penyakit");
        XLSX.writeFile(new_workbook, 'tmp_file.xls');
    })
});